export const LINKS = {
    shopifyTemplates: 'https://www.halothemes.com/template_category/shopify-templates/',
    halothemes: 'http://halothemes.com/',
    logo: 'https://watches-theme.myshopify.com/'
}