import React from 'react'

const Grid = () => {
    return (
        <div className='border-b-[1px] border-[#e8e8e8] border-solid pt-15 px-5 xl:px-28'></div>
    )
}
export default Grid
