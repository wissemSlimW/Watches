const Header = () => {
    return (
        <div className="text-white bg-black px-4 text-center">
            <div className="font-normal py-2 px-[25px]  text-sm">FREE SHIPPING ON ALL ORDERS</div>
        </div>
    )
}

export default Header