interface Collection {
    id: string,
    img: number,
    name: string,
}